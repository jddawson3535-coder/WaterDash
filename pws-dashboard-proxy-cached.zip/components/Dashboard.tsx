// Dashboard.tsx
"use client"

import React, { useEffect, useMemo, useRef, useState } from "react"
import {
  AlertTriangle, Bell, Calendar, CheckCircle2, ChevronRight, ClipboardList,
  Clock, Database, DollarSign, Info, MapPin, RefreshCw, Search as SearchIcon
} from "lucide-react"

// ===================== THEME (approx 120Water) =====================
const ThemeStyles = () => (
  <style>{`
    .tw120 {
      --primary:#0F5E9C; --primary-600:#2389DA; --primary-foreground:#fff;
      --bg:#F7FAFC; --card:#fff; --muted:#E7EEF5; --ring:#B7D3EA;
      --text:#0E2033; --text-muted:#6B7A8C; --danger:#C62828;
      --shadow:0 2px 6px rgba(15,94,156,.06),0 1px 2px rgba(14,32,51,.06);
      --shadow-lg:0 8px 24px rgba(15,94,156,.12),0 2px 6px rgba(14,32,51,.06);
    }
    .tw120 .card{background:var(--card); border:1px solid var(--muted); border-radius:12px; box-shadow:var(--shadow);}
    .tw120 .btn{display:inline-flex; align-items:center; gap:.5rem; padding:.5rem .75rem; border-radius:8px; font-weight:600;}
    .tw120 .btn-primary{background:var(--primary); color:var(--primary-foreground);}
    .tw120 .btn-primary:hover{background:var(--primary-600);}
    .tw120 .btn-outline{border:1px solid var(--ring); background:#fff;}
    .tw120 .btn-ghost{background:transparent;}
    .tw120 .badge{display:inline-flex; align-items:center; gap:.25rem; padding:.125rem .5rem; border-radius:9999px; font-size:.75rem; font-weight:600;}
    .tw120 .chip{background:var(--muted); color:var(--text-muted); border-radius:9999px; padding:2px 8px; font-size:12px; font-weight:500;}
    .tw120 .crit{background:#FFE5E5; color:#8A1F1F;}
    .tw120 .hi{background:#FFF1DB; color:#8A4B00;}
    .tw120 .med{background:#EAF5FF; color:#0F5E9C;}
    .tw120 .lo{background:#EAF7EA; color:#1F6A1F;}
    .tw120 .sheet{position:fixed; right:0; top:0; bottom:0; width:520px; max-width:100%; background:#fff; border-left:1px solid var(--muted); box-shadow:var(--shadow-lg); padding:1rem 1.25rem; overflow:auto;}
    .tw120 .input{border:1px solid var(--muted); border-radius:8px; padding:.5rem .75rem; background:#fff;}
    .tw120 .row{display:flex; gap:.75rem; align-items:center; flex-wrap:wrap;}
  `}</style>
)

// ===================== TYPES =====================
type DataType = "scada" | "water"
type ActionPriority = "Critical" | "High" | "Medium" | "Low"
type ActionCategory = "Compliance" | "Sampling" | "Inventory" | "SCADA" | "Funding"

type EchoSystem = {
  PWSID?: string; PWSName?: string; City?: string; County?: string;
  PopulationServed?: string; OwnerType?: string;
}
type EchoViolation = {
  PWSID?: string; ViolationCode?: string; ViolationType?: string;
  Contaminant?: string; BeginDate?: string; EndDate?: string; IsSignificant?: string;
}

type NextAction = {
  id: string; title: string; category: ActionCategory; priority: ActionPriority;
  dueDate?: string; description: string; steps: string[]; status: "Open"|"Completed"|"Snoozed";
}

// ===================== UTILS =====================
const clamp = (n:number, lo=0, hi=100)=> Math.max(lo, Math.min(hi, n))
const formatDate = (iso?:string)=> iso? new Date(iso+(iso.length===10?"T00:00:00":"")).toLocaleDateString(undefined,{year:"numeric",month:"short",day:"2-digit"}) : ""
const priorityClass = (p:ActionPriority)=> p==="Critical"?"crit":p==="High"?"hi":p==="Medium"?"med":"lo"
function useLocalStorage<T>(key:string, initial:T){
  const [state,setState]=useState<T>(()=>{ try{ const raw=localStorage.getItem(key); return raw? JSON.parse(raw): initial }catch{return initial}})
  useEffect(()=>{ try{ localStorage.setItem(key, JSON.stringify(state)) }catch{}},[key,state])
  return [state,setState] as const
}
function copy(text:string){ try{ navigator.clipboard?.writeText(text)}catch{} }

// Deep links
const linkDWW = (/* pwsid?:string */)=> `http://sdwis.deq.state.ok.us/DWW/index.jsp` // DWW has no stable deep link; we copy PWSID to clipboard.
const linkECHOFacility = (pwsid?:string)=> pwsid? `https://echo.epa.gov/detailed-facility-report?fid=${encodeURIComponent(pwsid)}` : `https://echo.epa.gov/tools/data-downloads/drinking-water`
const linkEnvirofactsPWS = (pwsid?:string)=> pwsid? `https://data.epa.gov/efservice/SDW_SYSTEMS/PWSID/${encodeURIComponent(pwsid)}` : `https://data.epa.gov/efservice`

// ===================== MINI STUBS (keep app standalone) =====================
function DataInputForm({ onDataSubmit }: { onDataSubmit:(data:any,type:DataType)=>void }){
  const [type,setType]=useState<DataType>("scada")
  const [payload,setPayload]=useState<any>({
    pressure_psi:62, turbidity_ntu:0.08, lead_ppb:3.2, chlorine_mgL:0.7,
    sampleDate:"2025-08-30", timestamp:new Date().toISOString()
  })
  return (
    <div className="card p-4">
      <div className="mb-2 row"><Database className="w-4 h-4 text-[var(--primary)]"/><h3 className="font-semibold">Data Input</h3></div>
      <p className="text-sm text-[var(--text-muted)] mb-3">Demo fields—replace with your real form later.</p>
      <form onSubmit={(e)=>{e.preventDefault(); onDataSubmit(payload,type)}} className="grid gap-3 md:grid-cols-2">
        <label className="grid gap-1">
          <span className="text-sm text-[var(--text-muted)]">Data Type</span>
          <select className="input" value={type} onChange={(e)=>setType(e.target.value as DataType)}>
            <option value="scada">SCADA</option>
            <option value="water">Water</option>
          </select>
        </label>
        <label className="grid gap-1">
          <span className="text-sm text-[var(--text-muted)]">{type==="scada"?"Pressure (psi)":"Lead (ppb)"}</span>
          <input className="input" type="number"
            value={type==="scada"?payload.pressure_psi:payload.lead_ppb}
            onChange={(e)=> setPayload((p:any)=> type==="scada"? {...p, pressure_psi:+e.target.value}:{...p, lead_ppb:+e.target.value})}/>
        </label>
        <div className="md:col-span-2 row">
          <button className="btn btn-primary" type="submit">Submit for Analysis</button>
          <span className="text-xs text-[var(--text-muted)]">Data stays local in this demo.</span>
        </div>
      </form>
    </div>
  )
}

function AIRecommendations({ data, dataType }: { data:any, dataType:DataType|null }){
  if(!data) return null
  const isScada = dataType==="scada"
  const notes = isScada
    ? [{t:"Pressure within normal range"},{t:"No abrupt flow anomalies detected"}]
    : [{t:"Lead below 15 ppb in latest sample"},{t:"Chlorine residual acceptable"}]
  return (
    <div className="card p-4">
      <div className="mb-2 row"><Info className="w-4 h-4 text-[var(--primary)]"/><h3 className="font-semibold">AI Recommendations</h3></div>
      <div className="grid md:grid-cols-3 gap-3">
        {notes.map((n,i)=> <div key={i} className="p-3 border rounded-lg bg-white text-sm">{n.t}</div>)}
      </div>
    </div>
  )
}

// ===================== LIVE FETCH HELPERS (no SWR; pure React) =====================
async function fetchJSON(url:string, signal?:AbortSignal) {
  const r = await fetch(url, { signal })
  if (!r.ok) throw new Error(`HTTP ${r.status}`)
  return r.json()
}
function useInterval(callback:()=>void, delay:number | null){
  const savedRef = useRef(callback)
  useEffect(()=>{ savedRef.current = callback },[callback])
  useEffect(()=>{
    if (delay===null) return
    const id = setInterval(()=>savedRef.current(), delay)
    return ()=> clearInterval(id)
  },[delay])
}

// ===================== NEXT ACTIONS (live-aware) =====================
function buildNextActions(violations: EchoViolation[], currentData:any, currentType:DataType|null): NextAction[] {
  const today=new Date(), inDays=(n:number)=>{const d=new Date(today); d.setDate(d.getDate()+n); return d.toISOString().slice(0,10)}
  const out: NextAction[] = []
  const significant = violations.filter(v => (v.IsSignificant ?? "").toUpperCase()==="Y")
  if (significant.length){
    out.push({
      id:"vio-sig",
      title:`Resolve ${significant.length} significant violations`,
      category:"Compliance",
      priority:"Critical",
      dueDate:inDays(7),
      description:"Review ECHO details, notify primacy if required, and document corrective actions.",
      steps:["Open ECHO facility report","Draft corrective action plan","Schedule follow-up sampling/ops changes"],
      status:"Open"
    })
  }
  if (currentType==="scada" && currentData){
    const p = Number(currentData.pressure_psi ?? 0)
    if (p && p<45){
      out.push({
        id:"scada-low-pressure",
        title:"Investigate low pressure trend",
        category:"SCADA",
        priority:"High",
        dueDate:inDays(1),
        description:"Sustained pressure <45 psi—check PRVs/valves and inspect for leaks.",
        steps:["Check PRV setpoints","Inspect for main breaks","Document remediation"],
        status:"Open"
      })
    }
  }
  // planning nudge
  out.push({
    id:"fund-1",
    title:"Prepare SRF set-aside application draft",
    category:"Funding",
    priority:"Medium",
    dueDate:inDays(21),
    description:"Draft scope & costs for LSLR or treatment improvements.",
    steps:["Export inventory counts","Draft phases & costs","Gather letters of support"],
    status:"Open"
  })
  const weight:Record<ActionPriority,number>={Critical:0,High:1,Medium:2,Low:3}
  return out.sort((a,b)=> (weight[a.priority]-weight[b.priority]) || ((a.dueDate?+new Date(a.dueDate):Infinity)-(b.dueDate?+new Date(b.dueDate):Infinity)))
}

// ===================== MAIN DASHBOARD (SINGLE FILE) =====================
export function Dashboard(){
  // — Theme + header
  const [auto, setAuto] = useLocalStorage("autorefresh", true)
  const loadedAt = useMemo(()=> new Date().toLocaleTimeString(), [])

  // — Data source controls
  const [state, setState] = useLocalStorage("state","OK")
  const [county, setCounty] = useLocalStorage("county","")
  const [pwsid, setPwsid] = useLocalStorage("pwsid","")
  const [apiKey, setApiKey] = useLocalStorage("echo_api_key","") // optional when proxy is OFF
  const [useProxy, setUseProxy] = useLocalStorage("use_proxy", true)

  // — Local operator input
  const [showForm, setShowForm] = useLocalStorage("showForm", false)
  const [currentData, setCurrentData] = useState<any>(null)
  const [currentType, setCurrentType] = useState<DataType|null>(null)

  // — Live data
  const [systems, setSystems] = useState<EchoSystem[]>([])
  const [violations, setViolations] = useState<EchoViolation[]>([])
  const [sysLoading, setSysLoading] = useState(false)
  const [vioLoading, setVioLoading] = useState(false)
  const [sysErr, setSysErr] = useState<string | null>(null)
  const [vioErr, setVioErr] = useState<string | null>(null)

  const controllerRef = useRef<AbortController | null>(null)

  const buildEchoUrl = (path:string, qs:Record<string,string | undefined>)=>{
    const base = useProxy ? "/api/echo" : "https://echodata.epa.gov/echo"
    const params = new URLSearchParams({ output:"JSON", state_abbr: state })
    if (!useProxy && apiKey) params.set("api_key", apiKey)
    if (county) params.set("county", county)
    if (pwsid) params.set("p_pwsid", pwsid)
    for (const [k,v] of Object.entries(qs)) if (v) params.set(k, v)
    return `${base}${path}?${params.toString()}`
  }

  const loadSystems = async ()=>{
    setSysErr(null); setSysLoading(true)
    controllerRef.current?.abort()
    const ctrl = new AbortController(); controllerRef.current = ctrl
    try {
      const url = buildEchoUrl("/sdw_rest_services.get_systems", {})
      const data = await fetchJSON(url, ctrl.signal)
      setSystems(Array.isArray(data?.Results?.Systems)? data.Results.Systems : [])
    } catch (e:any) {
      setSysErr(e?.message || "Failed to load systems")
    } finally { setSysLoading(false) }
  }
  const loadViolations = async ()=>{
    setVioErr(null); setVioLoading(true)
    const ctrl = new AbortController(); controllerRef.current = ctrl
    try {
      const url = buildEchoUrl("/sdw_rest_services.get_violations", {})
      const data = await fetchJSON(url, ctrl.signal)
      setViolations(Array.isArray(data?.Results?.Violations)? data.Results.Violations : [])
    } catch (e:any) {
      setVioErr(e?.message || "Failed to load violations")
    } finally { setVioLoading(false) }
  }

  // initial load + interval
  useEffect(()=>{ loadSystems(); loadViolations() /* eslint-disable-next-line */ },[])
  useInterval(()=>{ if (auto) { loadSystems(); loadViolations() } }, auto ? 60_000 : null)

  // next actions (live-aware)
  const nextActions = useMemo(()=> buildNextActions(violations, currentData, currentType), [violations, currentData, currentType])
  const [actions, setActions] = useLocalStorage<NextAction[]>("actions", nextActions)
  useEffect(()=>{ setActions(prev=>{ const m=new Map(prev.map(a=>[a.id,a])); return nextActions.map(a=> m.get(a.id)? {...a, status:m.get(a.id)!.status}: a) })},[nextActions,setActions])

  return (
    <div className="tw120 min-h-screen bg-[var(--bg)]">
      <ThemeStyles />
      <div className="max-w-7xl mx-auto p-6 space-y-8">

        {/* HEADER */}
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold text-[var(--text)]">PWS Dashboard</h1>
            <p className="text-[var(--text-muted)]">Live SDWIS via EPA ECHO • Oklahoma-focused</p>
          </div>
          <div className="row text-sm text-[var(--text-muted)]">
            <Clock className="w-4 h-4"/><span>Last loaded: {loadedAt}</span>
            <button className="btn btn-outline" onClick={()=>{ loadSystems(); loadViolations() }}>
              <RefreshCw className="w-4 h-4"/> Refresh
            </button>
            <label className="row text-sm"><input type="checkbox" checked={auto} onChange={e=>setAuto(e.target.checked)}/>Auto</label>
          </div>
        </div>

        {/* DATA SOURCE CONTROLS */}
        <div className="card p-4">
          <div className="mb-2 row"><Info className="w-4 h-4 text-[var(--primary)]"/><h3 className="font-semibold">Data Source</h3></div>
          <p className="text-sm text-[var(--text-muted)] mb-3">
            This pulls directly from EPA ECHO (SDWIS). Add an API key from <a href="https://api.data.gov/signup/" target="_blank" rel="noreferrer" className="underline">api.data.gov</a> for higher limits (optional).
          </p>
          <div className="grid md:grid-cols-4 gap-3">
            <label className="grid gap-1">
              <span className="text-sm text-[var(--text-muted)]">Use Server Proxy</span>
              <label className="row text-sm">
                <input type="checkbox" checked={useProxy} onChange={e=>setUseProxy(e.target.checked)} />
                <span>{useProxy ? "On (recommended)" : "Off"}</span>
              </label>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-[var(--text-muted)]">State</span>
              <input className="input" value={state} onChange={e=>setState(e.target.value.toUpperCase())}/>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-[var(--text-muted)]">County (optional)</span>
              <input className="input" value={county} onChange={e=>setCounty(e.target.value)}/>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-[var(--text-muted)]">PWSID (optional)</span>
              <input className="input" value={pwsid} onChange={e=>setPwsid(e.target.value)}/>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-[var(--text-muted)]">EPA API Key (optional)</span>
              <input className="input" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="api.data.gov key"/>
            </label>
          </div>
          <div className="mt-2 text-xs text-[var(--text-muted)]">Tip: using the proxy, you can enable CDN caching by appending <code>?ttl=300</code> in the URL your browser hits (the dashboard sets params automatically for you if you wire it into fetch calls).</div>
          <div className="mt-3 row">
            <button className="btn btn-primary" onClick={()=>{ loadSystems(); loadViolations() }}>
              <RefreshCw className="w-4 h-4"/> Apply & Reload
            </button>
          </div>
        </div>

        {/* OPERATOR INPUT + AI */}
        <div className="row">
          <button className="btn btn-primary" onClick={()=>setShowForm(v=>!v)}>
            <Database className="w-4 h-4"/>{showForm? "Hide Input":"Input Data"}
          </button>
          {showForm && <span className="text-sm text-[var(--text-muted)]">Enter SCADA or water sample data for real-time advice</span>}
        </div>
        {showForm && (
          <DataInputForm onDataSubmit={(d,t)=>{ setCurrentData(d); setCurrentType(t) }} />
        )}
        {currentData && <AIRecommendations data={currentData} dataType={currentType} />}

        {/* NEXT ACTIONS */}
        <div className="card p-4">
          <div className="mb-2 row"><Calendar className="w-4 h-4 text-[var(--primary)]"/><h3 className="font-semibold">Next Actions</h3></div>
          { (vioLoading && !violations.length) ? (
            <div className="p-3 text-sm text-[var(--text-muted)] border rounded-lg">Loading violations…</div>
          ) : vioErr ? (
            <div className="p-3 text-sm" style={{color:"var(--danger)"}}>Couldn't load violations.</div>
          ) : actions.filter(a=>a.status!=="Completed").length===0 ? (
            <div className="p-3 text-sm text-[var(--text-muted)] border rounded-lg">No open actions right now 🎉</div>
          ) : (
            <div className="grid gap-3">
              {actions.filter(a=>a.status!=="Completed").map(a=>(
                <div key={a.id} className="p-4 border rounded-lg bg-white">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="row mb-1">
                        <span className={`chip ${priorityClass(a.priority)==="crit"?"crit":priorityClass(a.priority)==="hi"?"hi":priorityClass(a.priority)==="med"?"med":"lo"}`}>{a.priority}</span>
                        <span className="chip">{a.category}</span>
                        {a.dueDate && <span className="chip row"><Calendar className="w-3 h-3"/>Due {formatDate(a.dueDate)}</span>}
                      </div>
                      <div className="row mb-1">
                        {a.category==="Compliance" && <ClipboardList className="w-4 h-4" />}
                        {a.category==="Sampling" && <Bell className="w-4 h-4" />}
                        {a.category==="Inventory" && <MapPin className="w-4 h-4" />}
                        {a.category==="SCADA" && <AlertTriangle className="w-4 h-4" />}
                        {a.category==="Funding" && <DollarSign className="w-4 h-4" />}
                        <h4 className="font-medium text-[var(--text)]">{a.title}</h4>
                      </div>
                      <p className="text-sm text-[var(--text-muted)]">{a.description}</p>
                      <ul className="list-disc list-inside text-sm mt-1">
                        {a.steps.map((s,i)=><li key={i}>{s}</li>)}
                      </ul>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <button className="btn btn-primary" onClick={()=>alert("Open detailed workflow…")}>
                        Open <ChevronRight className="w-4 h-4"/>
                      </button>
                      <button className="btn btn-outline" onClick={()=>{
                        const days=7
                        setActions(list=> list.map(x=> x.id===a.id? {
                          ...x,
                          status:"Snoozed",
                          dueDate:(()=>{
                            const base = x.dueDate? new Date(x.dueDate): new Date(); base.setDate(base.getDate()+days); return base.toISOString().slice(0,10)
                          })()
                        }: x))
                        setTimeout(()=> setActions(list=> list.map(x=> x.id===a.id? {...x, status:"Open"}: x)), 500)
                      }}>Snooze</button>
                      <button className="btn" style={{background:"var(--muted)"}} onClick={()=>{
                        setActions(list=> list.map(x=> x.id===a.id? {...x, status:"Completed"}:x))
                      }}>
                        <CheckCircle2 className="w-4 h-4"/> Complete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* LIVE SYSTEMS LIST + DEEP LINKS */}
        <section className="space-y-4">
          <div className="row">
            <h2 className="text-xl font-semibold text-[var(--text)]">Public Water Systems (live)</h2>
            <span className="badge" style={{background:"var(--muted)", color:"var(--text-muted)"}}>
              {sysLoading? "Loading…" : `${systems.length} found`}
            </span>
          </div>
          {sysErr ? (
            <div className="card p-4">
              <h4 className="font-semibold text-[var(--text)]">Couldn't load systems</h4>
              <p className="text-sm text-[var(--text-muted)]">Check your API key (optional), parameters, or try again.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {systems.slice(0,25).map((s,idx)=>{
                const id = s.PWSID ?? ""
                return (
                  <div key={`${id}-${idx}`} className="card p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-lg font-semibold text-[var(--text)]">{s.PWSName ?? "Unnamed System"}</div>
                        <div className="text-sm text-[var(--text-muted)]">{id || "PWSID N/A"} • {s.City ?? "—"}, {s.County ?? "—"}</div>
                        <div className="text-sm text-[var(--text-muted)]">Pop: {s.PopulationServed ?? "—"} • Owner: {s.OwnerType ?? "—"}</div>
                      </div>
                      <span className="badge" style={{background:"var(--primary)", color:"var(--primary-foreground)"}}>PWS</span>
                    </div>
                    <div className="mt-3 row">
                      <button className="btn btn-outline" onClick={()=> setPwsid(id)}>View Violations</button>
                      <a className="btn btn-outline" href={linkECHOFacility(id)} target="_blank" rel="noreferrer">Open in ECHO</a>
                      <a className="btn btn-outline" href={linkEnvirofactsPWS(id)} target="_blank" rel="noreferrer">Open in Envirofacts</a>
                      <a
                        className="btn btn-outline"
                        href={linkDWW()}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e)=>{ if(id){ copy(id); } }}
                        title="DWW doesn't support stable deep links; we copy the PWSID so you can paste in DWW."
                      >
                        Open DWW (PWSID copied)
                      </a>
                    </div>
                  </div>
                )
              })}
              {systems.length>25 && <div className="text-sm text-[var(--text-muted)]">Showing first 25. Narrow by county or PWSID.</div>}
        </div>
          )}
        </section>

        {/* SIMPLE DEMO REPORTS (LOCAL ONLY) */}
        <section className="space-y-3">
          <h2 className="text-xl font-semibold text-[var(--text)]">Recent Reports (demo)</h2>
          <div className="grid gap-3">
            {[{id:1,title:"August 2025 Lab Analysis",progress:75,date:"2025-08-30",type:"Lab Data",status:"In Progress" as const},{id:2,title:"SCADA Monthly Report",progress:100,date:"2025-08-28",type:"SCADA Data",status:"Completed" as const}].map(r=>{
              const pct=Math.max(0, Math.min(100, r.progress))
              return (
                <div key={r.id} className="card p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[var(--text)] font-semibold">{r.title}</div>
                      <div className="text-sm text-[var(--text-muted)]">{new Date((r.date||"") + "T00:00:00").toLocaleDateString(undefined,{year:"numeric",month:"short",day:"2-digit"})} • {r.type}</div>
                    </div>
                    <span className="badge" style={{background:r.status==="Completed"?"var(--primary)":"var(--muted)", color:r.status==="Completed"?"var(--primary-foreground)":"var(--text)"}}>{r.status}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-3 text-sm text-[var(--text-muted)]">
                    Progress: {pct}%
                    <div className="flex-1 h-2 rounded-full" style={{background:"var(--muted)"}}>
                      <div className="h-2 rounded-full" style={{width:`${pct}%`, background:"var(--primary)"}}/>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </section>

      </div>
    </div>
  )
}
