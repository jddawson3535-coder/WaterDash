import { NextRequest } from "next/server";

// Proxy to EPA ECHO with optional DATA_GOV_API_KEY from server env.
// Usage: /api/echo/<path>?<original query>
export const runtime = "edge"; // fast, globally distributed

export async function GET(req: NextRequest, { params }: { params: { slug?: string[] } }) {
  try {
    const slug = params.slug?.join("/") ?? "";
    const url = new URL(req.url);
    const qs = new URLSearchParams(url.search);

    // Inject API key from env if present and not already provided by client
    const envKey = process.env.DATA_GOV_API_KEY || process.env.ECHO_API_KEY;
    if (envKey && !qs.get("api_key")) qs.set("api_key", envKey);

    // Ensure JSON output by default if not explicitly set
    if (!qs.get("output")) qs.set("output", "JSON");

    // Optional CDN cache TTL (seconds)
    const ttl = Number(qs.get("ttl") || "0");

    // Build upstream request URL
    const upstream = new URL(`https://echodata.epa.gov/echo/${slug}`);
    upstream.search = qs.toString();

    const res = await fetch(upstream.toString(), {
      method: "GET",
      headers: {
        "cache-control": "s-maxage=300, stale-while-revalidate=600", "Accept": "application/json" },
      // Pass through caching hints (Edge runtime caches automatically on platform)
      cache: "force-cache", // can also use "no-store" if you want no caching
    });

    // Stream it back with minimal mutation
    const body = await res.text();

    // Prepare caching headers for CDN (s-maxage) with optional ttl
    const cacheHeaders: Record<string, string> = {};
    if (ttl > 0) {
      cacheHeaders["Cache-Control"] = `public, s-maxage=${ttl}, stale-while-revalidate=${Math.max(30, Math.floor(ttl/2))}`;
    } else {
      cacheHeaders["Cache-Control"] = "no-store";
    }

    return new Response(body, {
      status: res.status,
      headers: {
        "cache-control": "s-maxage=300, stale-while-revalidate=600",
        "content-type": res.headers.get("content-type") || "application/json",
        "x-upstream": upstream.toString(),
        **cacheHeaders,
      },
    });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || "Proxy error" }), {
      status: 500,
      headers: {
        "cache-control": "s-maxage=300, stale-while-revalidate=600", "content-type": "application/json" },
    });
  }
}
