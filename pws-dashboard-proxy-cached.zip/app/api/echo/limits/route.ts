import { NextRequest } from "next/server";

export const runtime = "edge";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const qs = new URLSearchParams(url.search);
    const envKey = process.env.DATA_GOV_API_KEY || process.env.ECHO_API_KEY;
    if (envKey && !qs.get("api_key")) qs.set("api_key", envKey);
    if (!qs.get("output")) qs.set("output", "JSON");

    // Minimal upstream request to surface rate-limit headers.
    // We ask for a single system in a small state to keep it light.
    const upstream = new URL("https://echodata.epa.gov/echo/sdw_rest_services.get_systems");
    if (!qs.get("state_abbr")) qs.set("state_abbr", "OK");
    if (!qs.get("p_pwsid")) qs.set("p_pwsid", "");
    upstream.search = qs.toString();

    const res = await fetch(upstream.toString(), { method: "GET", headers: { "Accept": "application/json" }, cache: "no-store" });
    const body = await res.text();

    // Pull rate-limit-ish headers if present (api.data.gov usually sets these)
    const rate = {
      x_ratelimit_limit: res.headers.get("x-ratelimit-limit"),
      x_ratelimit_remaining: res.headers.get("x-ratelimit-remaining"),
      x_ratelimit_reset: res.headers.get("x-ratelimit-reset"),
      x_cache: res.headers.get("x-cache")
    };

    return new Response(JSON.stringify({
      status: res.status,
      upstream: upstream.toString(),
      rate_headers: rate,
      sample: (()=>{ try{ return JSON.parse(body); } catch { return { note: "non-JSON or truncated" }; }})()
    }), {
      status: 200,
      headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || "limits diagnostic error" }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
}
